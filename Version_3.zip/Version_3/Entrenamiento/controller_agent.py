"""
ControllerAgent - Wrapper minimalista para usar DQNAgent.
"""

from typing import Tuple, Optional


class ControllerAgent:
    """Wrapper que usa DQNAgent para entrenar y retornar PIDs."""
    
    def __init__(self,
                 var_idx: int,
                 dqn_agent,
                 initial_pid: Tuple[float, float, float] = (1.0, 0.1, 0.05)):
        """
        Args:
            var_idx: Índice de la variable que controla
            dqn_agent: Instancia de tu DQNAgent
            initial_pid: PID inicial (Kp, Ki, Kd)
        """
        self.var_idx = var_idx
        self.dqn_agent = dqn_agent
        self.initial_pid = initial_pid
        self.pid_history = []
    
    def train(self,
              env,
              n_episodes: int,
              var_idx: int,
              setpoint: Optional[float] = None) -> Tuple[float, float, float]:
        """
        Entrenar DQN y extraer PID.
        
        Returns:
            Mejor PID (Kp, Ki, Kd)
        """
        # Configurar ambiente
        if setpoint is not None:
            env.set_setpoint(setpoint, var_idx=self.var_idx)
        
        # Entrenar n episodios
        for episode in range(n_episodes):
            state, info = env.reset()
            done = False
            
            while not done:
                action = self.dqn_agent.select_action(state, training=True)
                next_state, reward, terminated, truncated, info = env.step(action)
                done = terminated or truncated
                
                self.dqn_agent.store_experience(state, action, reward, next_state, done)
                
                if len(self.dqn_agent.memory) >= self.dqn_agent.batch_size:
                    self.dqn_agent.update()
                
                state = next_state
        
        # Extraer PID del ambiente
        best_pid = env.pid_action_space.get_current_pid()
        self.pid_history.append(best_pid)
        
        return best_pid
    
    def has_previous_pid(self) -> bool:
        """¿Tiene PID previo?"""
        return len(self.pid_history) > 0
    
    def get_previous_pid(self) -> Tuple[float, float, float]:
        """Obtener último PID."""
        if not self.has_previous_pid():
            return self.initial_pid
        return self.pid_history[-1]
    
    def reset_weights(self) -> None:
        """Resetear pesos (experimento desde cero)."""
        from algorithm_DQN import DQNAgent
        
        old_config = {
            'state_dim': self.dqn_agent.state_dim,
            'action_dim': self.dqn_agent.action_dim,
            'hidden_dims': self.dqn_agent.hidden_dims,
            'lr': self.dqn_agent.optimizer.param_groups[0]['lr'],
            'gamma': self.dqn_agent.gamma,
            'device': str(self.dqn_agent.device)
        }
        
        self.dqn_agent = DQNAgent(**old_config)
        self.pid_history = []
    
    def clear_buffers(self) -> None:
        """Limpiar replay buffer (transfer learning)."""
        self.dqn_agent.memory.clear()


# ============================================================
# EJEMPLO DE USO
# ============================================================

if __name__ == "__main__":
    print("\n" + "="*80)
    print("EJEMPLO: ControllerAgent con tu DQNAgent")
    print("="*80)
    
    # Importar tu DQNAgent
    from algorithm_DQN import DQNAgent
    
    # Crear tu DQNAgent
    dqn = DQNAgent(
        state_dim=6,
        action_dim=7,
        hidden_dims=(128, 128, 64),
        lr=0.001,
        gamma=0.99,
        device='cpu'
    )
    
    # Crear ControllerAgent que lo wrappea
    controller = ControllerAgent(
        var_idx=0,
        dqn_agent=dqn,
        initial_pid=(1.0, 0.1, 0.05)
    )
    
    print(f"\n{controller}")
    
    print("\n>>> Uso en MultiAgentPIDEnv:")
    print("controllers = [")
    print("    ControllerAgent(var_idx=0, dqn_agent=DQNAgent(...)),")
    print("    ControllerAgent(var_idx=1, dqn_agent=DQNAgent(...)),")
    print("]")
    
    print("\n>>> Entrenar:")
    print("pid = controller.train(env, n_episodes=100, var_idx=0)")
    print("→ Usa tu DQNAgent internamente")
    print("→ Retorna (Kp, Ki, Kd)")
    
    print("\n>>> Verificar PID previo:")
    print(f"controller.has_previous_pid() = {controller.has_previous_pid()}")
    
    print("\n✅ Listo para usar con pid_trainer.py")
